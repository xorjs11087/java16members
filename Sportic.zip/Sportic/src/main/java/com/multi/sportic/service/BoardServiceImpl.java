package com.multi.sportic.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.multi.sportic.mapper.BoardMapper;
import com.multi.sportic.vo.BoardVO;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Inject
	BoardMapper mapper;

	@Override
	public void boardInsert(BoardVO vo) {
		mapper.boardInsert(vo);
	}

	@Override
	public BoardVO boardSelect(int no) {
		return mapper.boardSelect(no);
	}

	@Override
	public void hitCount(int no) {
		mapper.hitCount(no);
	}

	@Override
	public int commentInsert(BoardVO vo) {
		return mapper.commentInsert(vo);
	}

	@Override
	public List<BoardVO> boardList() {
		return mapper.boardList();
	}

	@Override
	public int commentUpdate(BoardVO vo) {
		return mapper.commentUpdate(vo);
	}

	@Override
	public String commentDelete(String sportic_member_nickname) {
		return mapper.commentDelete(sportic_member_nickname);
	}

	@Override
	public List<BoardVO> commentSelect(int no ) {
		return mapper.commentSelect(no);
	}
}
