package com.multi.sportic.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.multi.sportic.service.BoardService;
import com.multi.sportic.vo.BoardVO;

@Controller
public class BoardController {

	@Autowired
	BoardService service;

	// 게시판
	@GetMapping("/board/list")
	public ModelAndView boardList() {
		ModelAndView mav = new ModelAndView();
		;
		// DB선택(page, 검색)
		List<BoardVO> list = service.boardList();
		mav.addObject("bList", list);
		mav.setViewName("board/boardList");
		return mav;
	}

	@GetMapping("/board/write")
	public String boardWrite() {
		return "board/boardWrite";
	}

	// 글 등록(DB)
	@PostMapping("/board/writeOk")
	public ModelAndView boardWriteOk(BoardVO vo, HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();

		// vo.setSportic_member_nickname((String)request.getSession().getAttribute("logId"));
		try {
			service.boardInsert(vo);

			mav.setViewName("redirect:list");
		} catch (Exception e) {
			// mav.addObject("msg", "수정");
			e.printStackTrace();
			mav.setViewName("redirect:/board/boardResult");
		}

		return mav;
	}

	@GetMapping("/board/boardResult")
	public String boardResult() {
		return "board/boardResult";
	}

	// 글 내용보기
	@GetMapping("/board/view")
	// @GetMapping("/board/{no}")
	public ModelAndView boardView(int no) {
		ModelAndView mav = new ModelAndView();

		service.hitCount(no); // 조회수 증가
		BoardVO vo = service.boardSelect(no); // 레코드 선택

		mav.addObject("vo", vo);
		mav.setViewName("board/boardView");

		return mav;
	}

	// 댓글등록
	@PostMapping("/write")
	@ResponseBody
	public String commentInsert(BoardVO vo) {
		// vo.setSportic_member_nickname((String)request.getSession().getAttribute("logId"));

		int result = service.commentInsert(vo);
		System.out.println("afasgerghsdfhdfh");

		return result + "";
	}

	// 댓글 목록
	@GetMapping("/list")
	@ResponseBody
	public List<BoardVO> commentList(String sportic_member_nickname) {

		List<BoardVO> commentList = service.commentSelect(sportic_member_nickname);
		return commentList;
	}

	// 댓글 수정(DB)
	@PostMapping("/editOk")
	@ResponseBody
	public String replyEditOk(BoardVO vo) {
		return service.commentUpdate(vo) + "";
	}

	// 댓글 삭제
	@GetMapping("/delete")
	@ResponseBody
	public String replyDelete(String sportic_member_nickname) {
		return service.commentDelete(sportic_member_nickname);
	}
}
