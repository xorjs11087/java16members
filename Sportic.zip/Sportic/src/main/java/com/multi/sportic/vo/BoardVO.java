package com.multi.sportic.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BoardVO {
	private String recruit_region;
	private String sport;
	private String recruit_position;
	private String recruit_num;
	private String recruit_career;
	private String recruit_date;
	private String sns;
	private String team_intro_title;
	private String team_intro;
	private int hit;
	private int write_num;
	private String coment;
	private String sportic_member_nickname;
	private String comment;
	private int comment_pwd;
}
