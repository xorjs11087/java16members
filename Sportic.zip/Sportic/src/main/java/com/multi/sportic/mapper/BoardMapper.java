package com.multi.sportic.mapper;

import java.util.List;

import com.multi.sportic.vo.BoardVO;

public interface BoardMapper {
	public void boardInsert(BoardVO vo);
	public BoardVO boardSelect(int no);
	public void hitCount(int no);
	public int commentInsert(BoardVO vo); // 댓글
	public List<BoardVO> boardList();
	public List<BoardVO> commentSelect(int no); // 댓글 목록
	public int commentUpdate(BoardVO vo); // 댓글 수정(DB)
	public String commentDelete(String sportic_member_nickname); // 댓글 삭제
}
