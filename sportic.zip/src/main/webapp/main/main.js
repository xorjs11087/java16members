//예시로 하나 넣은 샘플 데이터.
var loginInfo = {
    
    userEmail: "korea@gmail.com",
    userPassword: "korea7771"
};

// 사용자 정보를 양식 필드에 로드.
//나의 정보에서 취소 버튼을 클릭하면 userInfo 내용으로 초기화.(이름, 전화번호, 이메일, 지역)
function loadUserInformation() {
   
    document.getElementById("userEmail").value = loginInfo.userEmail;
    document.getElementById("userPassword").value = loginInfo.userPassword;
   
}


